To use the VMp1.py to translate a vm files to asm, type the following into the command line

python3 VMp1.py filename

(this code assumes that filename ends in a .vm extension)